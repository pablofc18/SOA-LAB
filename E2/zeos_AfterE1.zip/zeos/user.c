#include <libc.h>

char buff[24];

int pid;

void intToChar(int num, char *str) {
    int i = 0;
    int isNegative = 0;

    // Handle negative numbers
    if (num < 0) {
        isNegative = 1;
        num = -num;
    }

    // Convert digits to characters in reverse order
    do {
        str[i++] = num % 10 + '0';
        num /= 10;
    } while (num != 0);

    // Add '-' sign if the number was negative
    if (isNegative)
        str[i++] = '-';

    // Reverse the string
    int j;
    char temp;
    for (j = 0; j < i / 2; j++) {
        temp = str[j];
        str[j] = str[i - j - 1];
        str[i - j - 1] = temp;
    }

    // Null-terminate the string
    str[i] = '\0';
}

int __attribute__ ((__section__(".text.main")))
  main(void)
{
    /* Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception */
     /* __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) ); */

  char * msg;
  msg = "\nHola [write] desde el user\n";
  write(1, msg, strlen(msg));  
  char * m = "h";
  while(1) { 
	  int t = gettime();
  	intToChar(t,m);
  	write(1,m,strlen(m)); 
}
}
