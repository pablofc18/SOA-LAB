/*
 * sched.c - initializes struct for task 0 anda task 1
 */

#include <sched.h>
#include <mm.h>
#include <io.h>

union task_union task[NR_TASKS]
  __attribute__((__section__(".data.task")));

#if 0
struct task_struct *list_head_to_task_struct(struct list_head *l)
{
  return list_entry( l, struct task_struct, list);
}
#endif

struct task_struct *list_head_to_task_struct(struct list_head *l)
{
	
	l = l & 0xFFFFF000;
	 
}

extern struct list_head blocked;
struct list_head freequeue;
struct list_head readyqueue;

/* get_DIR - Returns the Page Directory address for task 't' */
page_table_entry * get_DIR (struct task_struct *t) 
{
	return t->dir_pages_baseAddr;
}

/* get_PT - Returns the Page Table address for task 't' */
page_table_entry * get_PT (struct task_struct *t) 
{
	return (page_table_entry *)(((unsigned int)(t->dir_pages_baseAddr->bits.pbase_addr))<<12);
}


int allocate_DIR(struct task_struct *t) 
{
	int pos;

	pos = ((int)t-(int)task)/sizeof(union task_union);

	t->dir_pages_baseAddr = (page_table_entry*) &dir_pages[pos]; 

	return 1;
}

void cpu_idle(void)
{
	__asm__ __volatile__("sti": : :"memory");

	while(1)
	{
	;
	}
}

void init_idle (void)
{
	// es un -> while(1); // nunca sale a user, solo sistema, hay que preparar para q se ejecute contexto de ejecucion, pila de sistema para q idle entre en cpu y qno permita ir a usuario. (Cima pila sistema haya un ebp que pueda recuperar y una dir de retorno a su codigo). Pila sistema no hay context HW SW, solo info minima ebp y @RET. Crear a mano pila <-. ((((Añadir task struct kernel_esp)))). EBP -> 0. @RET -> dir funcion codigo idle cpu_idle (en codigo del kernel). IDLE NUNCA EN LA COLA DE READY. Puntero global a su task union. 
}

void init_task1(void)
{
	// Codigo para crear el proceso a mano, primer proceso de user, tabla pàg proceso: Definir como es ((mm_addres.h)). setuserpages (crea primera tabla pags, llamarla). Prepararlo para indicar que es current(): cr3 -> tabla pag de este proceso. tss.esp0 -> pila sistema de task1 cima. msr 0x175-> pila sistema del proc actual. TASK1 NO SE ENCOLA EN READY QUEUE. 
}

// pila sistema del proc actual: current devuelve task struct pointer. (pila sist no definida en task struct). 
// Task struct a task union -> cast indirecto. struct task struct pointer p -> (union task union *)p)->stack

void init_sched()
{
  // ini structures 
  // ready vacia, free añadir todos task unions
}

struct task_struct* current()
{
  int ret_value;
  
  __asm__ __volatile__(
  	"movl %%esp, %0"
	: "=g" (ret_value)
  );
  return (struct task_struct*)(ret_value&0xfffff000);
}

